
import React, { useState } from 'react'

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000/api'

function Login({ onDone }) {
  const [email, setEmail] = useState('')
  const [step, setStep] = useState(1)
  const [code, setCode] = useState('')
  const [devCode, setDevCode] = useState('')

  const start = async () => {
    const r = await fetch(API + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email })
    })
    const j = await r.json()
    if (j.ok) {
      setDevCode(j.devCode || '')
      setStep(2)
    } else {
      alert(j.error || 'Erro')
    }
  }

  const verify = async () => {
    const r = await fetch(API + '/auth/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, code })
    })
    const j = await r.json()
    if (j.ok) onDone()
    else alert(j.error || 'Erro')
  }

  return (
    <div style={{ maxWidth: 420, margin: '60px auto', fontFamily: 'sans-serif' }}>
      <h1>Docu8 – Login</h1>
      {step === 1 && (
        <div>
          <input placeholder="Seu e-mail" value={email} onChange={e => setEmail(e.target.value)} style={{ width: '100%', padding: 10, marginBottom: 10 }} />
          <button onClick={start} style={{ padding: 10, width: '100%' }}>Enviar código</button>
        </div>
      )}
      {step === 2 && (
        <div>
          {devCode && <p style={{ background: '#eef', padding: 8 }}>Código (dev): <b>{devCode}</b></p>}
          <input placeholder="Código de 6 dígitos" value={code} onChange={e => setCode(e.target.value)} style={{ width: '100%', padding: 10, marginBottom: 10 }} />
          <button onClick={verify} style={{ padding: 10, width: '100%' }}>Entrar</button>
        </div>
      )}
    </div>
  )
}

function Dashboard() {
  const [clientName, setClientName] = useState('Cliente Exemplo')
  const [service, setService] = useState('Prestação de Serviços')
  const [price, setPrice] = useState('R$ 1.000,00')
  const [markdown, setMarkdown] = useState('')
  const [pdfPath, setPdfPath] = useState('')

  const generate = async () => {
    const r = await fetch(API + '/contracts/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ title: 'Contrato de Serviços', data: { clientName, service, price } })
    })
    const j = await r.json()
    if (j.ok) setMarkdown(j.markdown)
  }

  const toPDF = async () => {
    const r = await fetch(API + '/contracts/pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ markdown })
    })
    const j = await r.json()
    if (j.ok) setPdfPath(j.pdfPath)
  }

  return (
    <div style={{ maxWidth: 800, margin: '40px auto', fontFamily: 'sans-serif' }}>
      <h2>Gerar Contrato Rápido</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <input placeholder="Nome do cliente" value={clientName} onChange={e => setClientName(e.target.value)} />
        <input placeholder="Serviço" value={service} onChange={e => setService(e.target.value)} />
        <input placeholder="Preço" value={price} onChange={e => setPrice(e.target.value)} />
      </div>
      <div style={{ marginTop: 12 }}>
        <button onClick={generate} style={{ padding: 10, marginRight: 10 }}>Gerar</button>
        <button onClick={toPDF} style={{ padding: 10 }}>Exportar PDF</button>
      </div>
      <h3>Markdown</h3>
      <textarea value={markdown} onChange={e => setMarkdown(e.target.value)} rows={14} style={{ width: '100%' }} />
      {pdfPath && (
        <p>PDF gerado em: <code>{pdfPath}</code></p>
      )}
    </div>
  )
}

export default function App() {
  const [logged, setLogged] = React.useState(false)

  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch((import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000/api') + '/auth/me', { credentials: 'include' })
        if (r.ok) setLogged(true)
      } catch {}
    })()
  }, [])

  if (!logged) return <Login onDone={() => setLogged(true)} />
  return <Dashboard />
}
