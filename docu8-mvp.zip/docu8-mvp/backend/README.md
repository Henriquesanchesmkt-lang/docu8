
# Docu8 Backend (MVP)

Stack: Node.js + Express + Prisma/PostgreSQL + PDFKit + Stripe (placeholder).

## Setup
1. Copy `.env.example` to `.env` and adjust values.
2. Install: `npm install`
3. Generate client: `npm run prisma:generate`
4. Migrate: `npm run prisma:migrate`
5. Start: `npm start`

## Key Endpoints
- `POST /api/auth/login` → start OTP (returns `devCode` in non-production)
- `POST /api/auth/verify` → verify code, sets `token` cookie
- `GET /api/auth/me` → current user
- `POST /api/contracts/generate` → returns markdown + creates Contract
- `POST /api/contracts/pdf` → returns `pdfPath` and stores on disk
- `POST /api/billing/subscribe` → placeholder
- `POST /api/billing/webhook` → placeholder
- `GET /api/health` → healthcheck
