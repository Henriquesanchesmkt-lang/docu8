
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import jwt from 'jsonwebtoken';
import fs from 'fs';
import path from 'path';
import bodyParser from 'body-parser';
import PDFDocument from 'pdfkit';
import { fileURLToPath } from 'url';
import { PrismaClient } from '@prisma/client';
import Stripe from 'stripe';

const prisma = new PrismaClient();
const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'secret';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';
const STORAGE_DIR = process.env.PDF_STORAGE_DIR || path.join(__dirname, '..', 'storage');
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || 'sk_test_xxx';
const stripe = new Stripe(STRIPE_SECRET_KEY);

// Raw body for webhook
app.use((req, res, next) => {
  if (req.path === '/api/billing/webhook') {
    bodyParser.raw({ type: '*/*' })(req, res, next);
  } else {
    next();
  }
});

app.use(cors({ origin: FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(cookieParser());

if (!fs.existsSync(STORAGE_DIR)) {
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
}

const requireAuth = async (req, res, next) => {
  try {
    const token = req.cookies?.token || (req.headers.authorization?.split(' ')[1]);
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
};

const OTP_TTL_MS = 5 * 60 * 1000;
const devMode = process.env.NODE_ENV !== 'production';

app.post('/api/auth/login', async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ error: 'email required' });

  let user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    user = await prisma.user.create({ data: { email } });
  }

  const code = (Math.floor(100000 + Math.random() * 900000)).toString();
  const expiresAt = new Date(Date.now() + OTP_TTL_MS);

  await prisma.otpCode.create({ data: { userId: user.id, code, expiresAt } });

  console.log('[OTP] Code for', email, '=>', code);
  return res.json({ ok: true, devCode: devMode ? code : undefined });
});

app.post('/api/auth/verify', async (req, res) => {
  const { email, code } = req.body || {};
  if (!email || !code) return res.status(400).json({ error: 'email & code required' });

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(400).json({ error: 'invalid user' });

  const otp = await prisma.otpCode.findFirst({
    where: { userId: user.id, code },
    orderBy: { createdAt: 'desc' }
  });
  if (!otp) return res.status(400).json({ error: 'invalid code' });
  if (new Date(otp.expiresAt).getTime() < Date.now()) return res.status(400).json({ error: 'expired code' });

  const token = jwt.sign({ uid: user.id, email: user.email, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax' });
  return res.json({ ok: true, user: { id: user.id, email: user.email, isAdmin: user.isAdmin } });
});

app.get('/api/auth/me', requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.uid } });
  return res.json({ user });
});

app.post('/api/contracts/generate', requireAuth, async (req, res) => {
  const { title = 'Contrato de Prestação de Serviços', data = {} } = req.body || {};

  const md = `# ${title}

**Contratante:** ${data.clientName || '---'}
**Serviço:** ${data.service || '---'}
**Valor:** ${data.price || '---'}
**Data:** ${new Date().toLocaleDateString()}

## Cláusulas
1. O Contratado se compromete a executar o serviço acima descrito.
2. O pagamento será efetuado conforme combinado pelas partes.
3. Foro da comarca do contratante.

---
*Gerado automaticamente pelo Docu8.*`;

  const contract = await prisma.contract.create({
    data: {
      title,
      data,
      markdown: md,
      userId: req.user.uid
    }
  });

  res.json({ ok: true, id: contract.id, markdown: md });
});

app.post('/api/contracts/pdf', requireAuth, async (req, res) => {
  const { markdown = '', id } = req.body || {};
  const filename = `contract_${id || Date.now()}.pdf`;
  const filePath = path.join(STORAGE_DIR, filename);

  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);

  const lines = markdown.split('\\n');
  lines.forEach((line) => {
    if (line.startsWith('# ')) {
      doc.fontSize(20).text(line.replace('# ', ''), { underline: false });
    } else if (line.startsWith('## ')) {
      doc.moveDown(0.3);
      doc.fontSize(14).text(line.replace('## ', ''), { underline: true });
      doc.moveDown(0.2);
    } else {
      doc.fontSize(12).text(line);
    }
    doc.moveDown(0.2);
  });

  doc.end();

  stream.on('finish', async () => {
    if (id) {
      await prisma.contract.update({ where: { id }, data: { pdfPath: filePath } });
    }
    res.json({ ok: true, pdfPath: filePath });
  });

  stream.on('error', (err) => {
    console.error(err);
    res.status(500).json({ error: 'PDF error' });
  });
});

app.post('/api/billing/subscribe', requireAuth, async (req, res) => {
  // Placeholder checkout url
  return res.json({ url: '#' });
});

app.post('/api/billing/webhook', async (req, res) => {
  // Validate signature in a real setup. Placeholder here.
  res.status(200).send('ok');
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log('Docu8 API listening on port', PORT);
});
